package com.virtusa.pricecalculator;

public class CalculatorFactoryPatternMain {
	
	
	 public static void main(String[] args) {
		 CalculatorFactory calculatorFactory = new CalculatorFactory();

	     
		 CalculatorInterface calculatorAref = calculatorFactory.priceCalculation("A");
		 int priceA = calculatorAref.priceCalculator(4);
		 System.out.println(priceA);

		 CalculatorInterface calculatorBref = calculatorFactory.priceCalculation("B");
		 int priceB = calculatorBref.priceCalculator(5);
		 System.out.println(priceB);
		 
		 CalculatorInterface calculatorCref = calculatorFactory.priceCalculation("C");
		 int priceC =calculatorCref.priceCalculator(11);
		 System.out.println(priceC);
		 
		 CalculatorInterface calculatorDref = calculatorFactory.priceCalculation("D");
		 int priceD =calculatorDref.priceCalculatorForAD(10, 9);
		 System.out.println(priceD);
		 
		 CalculatorInterface calculatorEref = calculatorFactory.priceCalculation("E");
		 int priceE =calculatorEref.priceCalculator(8);
		 System.out.println(priceE);
		 
	   }

}
