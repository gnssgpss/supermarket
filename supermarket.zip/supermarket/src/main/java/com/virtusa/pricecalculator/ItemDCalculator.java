package com.virtusa.pricecalculator;

public class ItemDCalculator implements CalculatorInterface{

	@Override
	public int priceCalculator(int noOfItems) {
		// TODO Auto-generated method stub
		return 0;
	}

}
