
package com.virtusa.pricecalculator;

public class ItemCcalculator implements CalculatorInterface {

	@Override
	public int priceCalculator(int noOfItems) {

		// plan 1C
		for (int i = 2;  i < noOfItems / 2; i++) {
			int temp = noOfItems % i;
			if (temp != 0) {

				int quotient = noOfItems / 1;
				int A_Price = (int) (quotient * 20);
				return A_Price;

			}

		}

		// plan 2c
		for (int i = 2; i < noOfItems / 2; i++) {
			int temp = noOfItems % i;
			if (temp != 0 ) {

				int quotient = noOfItems / 1;
				int A_Price = (int) (quotient * 20);
				return A_Price;

			}

		}
		
		
		
		
		if (noOfItems % 2 == 0  ) {
			int quotient = noOfItems / 2;
			int A_Price = (int) (quotient * 38);
			return A_Price;
		}

		// plan 3c
		if (noOfItems % 3 == 0) {
			int quotient = noOfItems / 3;
			int A_Price = (int) (quotient * 50);
			return A_Price;
		}

		// plan 1c,2c

		if (noOfItems % 2 == 1) {

			int quotient = noOfItems / 2;
			int remainder = noOfItems % 2;
			int A_Price = (int) (quotient * 38) + (remainder * 20);
			return A_Price;
		}

		// plan 1c,3c
		if (noOfItems % 3 == 1) {
			int quotient = noOfItems / 3;
			int remainder = noOfItems % 3;
			int A_Price = (int) (quotient * 50) + (remainder * 20);
			return A_Price;
		}

		// plan 2c,3c
		if (noOfItems % 3 == 2) {
			int quotient = noOfItems / 3;
			int remainder = noOfItems % 3;
			int A_Price = (int) (quotient * 50) + (remainder * 38);
			return A_Price;
		}
		return (Integer) null;

		/*
		 * // plan 1c, 2c, 3c
		 * 
		 * if(noOfItems%3==3){remainder=noOfItems%3;if(remainder==1){A_Price=(int)(
		 * quotient*50)+(remainder*38);return A_Price;}
		 * 
		 */}

}
