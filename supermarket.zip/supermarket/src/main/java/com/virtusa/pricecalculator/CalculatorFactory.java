package com.virtusa.pricecalculator;

public class CalculatorFactory {
	
	
	public CalculatorInterface priceCalculation(String itemtype) {
		
		
		if(itemtype == null){
	         return null;
	      }		
	      if(itemtype.equalsIgnoreCase("A")){
	         return new ItemAcalculator();
	         
	      } else if(itemtype.equalsIgnoreCase("B")){
	         return new ItemBcalculator();
	         
	      } else if(itemtype.equalsIgnoreCase("C")){
		         return new ItemCcalculator();
	      }else if(itemtype.equalsIgnoreCase("D")){
		         return new ItemDCalculator();
	      }else if(itemtype.equalsIgnoreCase("E")){
		         return new ItemEcalculator();
	      
	   }
		return null;
	}
}
