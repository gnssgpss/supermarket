package com.virtusa.pricecalculator;

public class ItemEcalculator implements CalculatorInterface{

	@Override
	public int priceCalculator(int noOfItems) {
		return noOfItems * 5;
	}

}
