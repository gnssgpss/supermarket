package com.virtusa.pricecalculator;

public interface CalculatorInterface {
	
	int priceCalculator(int noOfItems);
	
	default int priceCalculatorForAD(int AnoOfItems, int DnoOfItems) {
		if (AnoOfItems > 0) {

			int discouned_Ditems = 0;
			int non_discounted_items = 0;

			if (DnoOfItems > AnoOfItems) {
				discouned_Ditems = AnoOfItems;
				non_discounted_items = DnoOfItems - discouned_Ditems;
				return (discouned_Ditems * 5) + (non_discounted_items * 15);
			}

			else {
				discouned_Ditems = DnoOfItems;
				return discouned_Ditems * 5;
			}

		}

		else {
			return DnoOfItems * 15;
		}
	}
	

}
