package com.virtusa.pricecalculator;

public class ItemBcalculator implements CalculatorInterface {

	@Override
	public int priceCalculator(int noOfItems) {
		if (noOfItems < 2) {
			return noOfItems * 30;
		}

		if (noOfItems % 2 == 0) {
			int quotient = noOfItems / 2;
			int A_Price = (int) (quotient * 45);
			return A_Price;
		} else {
			int quotient = noOfItems / 2;
			int remainder = noOfItems % 2;
			int A_Price = (quotient * 45) + (remainder * 30);
			return A_Price;
		}
	}

}
