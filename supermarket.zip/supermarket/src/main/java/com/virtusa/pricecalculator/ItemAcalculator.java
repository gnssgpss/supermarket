package com.virtusa.pricecalculator;

public class ItemAcalculator implements CalculatorInterface{



	@Override
	public int priceCalculator(int noOfItems) {
		if (noOfItems < 3) {
			return noOfItems * 50;
		}

		if (noOfItems % 3 == 0) {
			int quotient = noOfItems / 3;
			int A_Price = (int) (quotient * 130);
			return A_Price;
		} else {
			int quotient = noOfItems / 3;
			int remainder = noOfItems % 3;
			int A_Price = (quotient * 130) + (remainder * 50);
			return A_Price;
		}

	}

}
